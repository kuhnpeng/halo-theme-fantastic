## 预览地址
[访问](https://www.imkun.dev)

## 预览截图
![Screenshot_2019-10-03 知否](https://www.imkun.dev/upload/2019/10/Screenshot_2019-10-03%20%E7%9F%A5%E5%90%A6-67657c9bdcdd4b25aa75c885fc778324.png)
![Screenshot_2019-10-03 知否(1)](https://www.imkun.dev/upload/2019/10/Screenshot_2019-10-03%20%E7%9F%A5%E5%90%A6(1)-4c1b30f8eef2418e95c8d95d63f6168e.png)
## 使用方法

1. 克隆或者[下载](https://codeload.github.com/imkundev/halo-theme-fantastic/zip/master)。
2. 压缩为 zip 压缩包之后在后台的主题设置直接上传即可使用。
3. 用Halo自还的程序拉取 `https://github.com/imkundev/halo-theme-fantastic.git`
